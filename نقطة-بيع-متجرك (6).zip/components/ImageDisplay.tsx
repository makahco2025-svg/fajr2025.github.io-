/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import type { CartItem } from '../types';

interface CartProps {
  items: CartItem[];
  onUpdateQuantity: (productId: string, newQuantity: number) => void;
  onCheckout: () => void;
  formatCurrency: (amount: number) => string;
  subtotal: number;
  tax: number;
  total: number;
}

export const Cart: React.FC<CartProps> = ({ items, onUpdateQuantity, onCheckout, formatCurrency, subtotal, tax, total }) => {
  return (
    <div className="bg-gray-800/50 rounded-lg p-4 flex flex-col h-full">
      <h2 className="text-xl font-bold border-b border-gray-600 pb-2 mb-4">البيع الحالي</h2>
      {items.length === 0 ? (
        <p className="text-gray-400 flex-grow text-center flex items-center justify-center">السلة فارغة. امسح منتجًا للبدء.</p>
      ) : (
        <div className="flex-grow overflow-y-auto pl-2">
          {items.map(item => (
            <div key={item.id} className="flex justify-between items-center mb-3">
              <div>
                <p className="font-semibold">{item.name} {item.isTaxable && <span className="text-xs bg-cyan-800 px-1 rounded-full">ض</span>}</p>
                <p className="text-sm text-gray-400">{formatCurrency(item.price)}</p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => onUpdateQuantity(item.id, item.quantity - 1)} className="w-6 h-6 bg-gray-600 rounded-full">-</button>
                <span>{item.quantity}</span>
                <button onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} className="w-6 h-6 bg-gray-600 rounded-full">+</button>
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="border-t border-gray-600 pt-4 mt-4 space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-400">المجموع الفرعي</span>
          <span>{formatCurrency(subtotal)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">إجمالي الضريبة</span>
          <span>{formatCurrency(tax)}</span>
        </div>
        <div className="flex justify-between font-bold text-base">
          <span>المجموع</span>
          <span>{formatCurrency(total)}</span>
        </div>
      </div>
      <button 
        onClick={onCheckout}
        disabled={items.length === 0}
        className="w-full bg-cyan-600 text-white font-bold py-3 mt-4 rounded-md hover:bg-cyan-500 transition disabled:bg-gray-600 disabled:cursor-not-allowed"
      >
        إتمام البيع
      </button>
    </div>
  );
};