/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import type { Product } from '../types';

interface ProductCatalogProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onEditProduct: (product: Product) => void;
  formatCurrency: (amount: number) => string;
  canEditProducts: boolean;
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({ products, onAddToCart, onEditProduct, formatCurrency, canEditProducts }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4 bg-gray-800/50 rounded-lg overflow-y-auto">
      {products.length > 0 ? (
        products.map((product) => {
          const isOutOfStock = product.stock <= 0;
          return (
            <div
              key={product.id}
              className={`bg-gray-700 rounded-lg text-center transition-transform relative group ${isOutOfStock ? 'opacity-50' : 'transform hover:scale-105'}`}
            >
              <button
                onClick={() => onAddToCart(product)}
                className="w-full h-full p-3 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-cyan-500 rounded-lg disabled:cursor-not-allowed"
                aria-label={`إضافة ${product.name} إلى السلة`}
                disabled={isOutOfStock}
              >
                <img src={product.imageUrl} alt={product.name} className="w-full h-24 object-contain mb-2" />
                <h3 className="font-bold text-sm">{product.name}</h3>
                <p className="text-cyan-400 text-xs">{formatCurrency(product.price)}</p>
                <p className="text-xs text-gray-400 mt-1">الرصيد: {product.stock}</p>
              </button>
              {isOutOfStock && (
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-red-800/80 text-white text-xs font-bold px-2 py-1 rounded select-none">
                    نفذ المخزون
                  </div>
              )}
              {canEditProducts && (
                <button
                  onClick={() => onEditProduct(product)}
                  className="absolute top-1 left-1 bg-gray-800/80 p-1.5 rounded-full text-xs opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-600 focus:opacity-100 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  aria-label={`تعديل ${product.name}`}
                >
                  ✏️
                </button>
              )}
            </div>
          );
        })
      ) : (
        <p className="col-span-full text-center text-gray-400 py-10">
          لا توجد منتجات تطابق بحثك.
        </p>
      )}
    </div>
  );
};