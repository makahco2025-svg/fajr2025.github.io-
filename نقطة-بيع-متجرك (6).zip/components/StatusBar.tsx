/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React, { useState, useEffect } from 'react';
import type { User, Permissions } from '../types';

interface HeaderProps {
  currentUser: User;
  permissions: Permissions & { canEditProducts: boolean };
  onAddProductClick: () => void;
  onReportsClick: () => void;
  onImportClick: () => void;
  onPurchaseInvoiceClick: () => void;
  onReturnsClick: () => void; // New prop for returns
  onUsersManagementClick: () => void;
  onChangePasswordClick: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentUser, permissions, onAddProductClick, onReportsClick, onImportClick, onPurchaseInvoiceClick, onReturnsClick, onUsersManagementClick, onChangePasswordClick, onLogout }) => {
  const [currentDateTime, setCurrentDateTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formattedDate = currentDateTime.toLocaleDateString('ar-EG', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const formattedTime = currentDateTime.toLocaleTimeString('ar-EG', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
  
  const roleName = currentUser.role === 'admin' ? 'مدير' : 'مستخدم';

  return (
    <header className="w-full p-4 bg-gray-800/50 mb-4 rounded-lg flex justify-between items-center flex-wrap gap-y-4">
      <div className="flex items-center gap-4">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-9 w-9 text-cyan-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
        <div>
            <h1 className="text-2xl font-bold text-cyan-400 tracking-wider">نقطة بيع متجرك</h1>
            <div className="text-sm text-gray-400 mt-1">
                <span>{formattedDate}</span>
                <span className="mx-2">|</span>
                <span>{formattedTime}</span>
            </div>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap justify-end">
        <div className="text-right ml-4">
            <p className="text-sm font-bold">{currentUser.username}</p>
            <p className="text-xs text-gray-400">{roleName}</p>
        </div>
        
        {permissions.canProcessReturns && (
          <button 
            onClick={onReturnsClick}
            className="bg-orange-600 text-white font-bold py-2 px-4 rounded-md hover:bg-orange-500 transition text-sm"
            aria-label="معالجة المرتجعات"
          >
            المرتجعات
          </button>
        )}

        {permissions.canManagePurchases && (
          <button 
            onClick={onPurchaseInvoiceClick}
            className="bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-500 transition text-sm"
            aria-label="إنشاء فاتورة مشتريات جديدة"
          >
            فاتورة مشتريات
          </button>
        )}

        {permissions.canManageProducts && (
          <button 
            onClick={onImportClick}
            className="bg-gray-600 text-white font-bold py-2 px-4 rounded-md hover:bg-gray-500 transition text-sm"
            aria-label="استيراد منتجات من ملف Excel"
          >
            استيراد
          </button>
        )}

        {permissions.canViewReports && (
          <button 
            onClick={onReportsClick}
            className="bg-gray-600 text-white font-bold py-2 px-4 rounded-md hover:bg-gray-500 transition text-sm"
            aria-label="عرض تقارير المبيعات"
          >
            التقارير
          </button>
        )}

        {permissions.canManageProducts && (
          <button 
            onClick={onAddProductClick}
            className="bg-cyan-600 text-white font-bold py-2 px-4 rounded-md hover:bg-cyan-500 transition text-sm"
            aria-label="إضافة منتج جديد"
          >
            + إضافة منتج
          </button>
        )}
        
        {currentUser.role === 'admin' && (
           <button 
            onClick={onUsersManagementClick}
            className="bg-yellow-600 text-white font-bold py-2 px-4 rounded-md hover:bg-yellow-500 transition text-sm"
            aria-label="إدارة المستخدمين والصلاحيات"
          >
            إدارة المستخدمين
          </button>
        )}

        <button 
          onClick={onChangePasswordClick}
          className="bg-gray-600 text-white font-bold py-2 px-4 rounded-md hover:bg-gray-500 transition text-sm"
          aria-label="تغيير كلمة المرور"
        >
          تغيير كلمة المرور
        </button>

        <button 
          onClick={onLogout}
          className="bg-red-600 text-white font-bold py-2 px-4 rounded-md hover:bg-red-500 transition text-sm"
          aria-label="تسجيل الخروج"
        >
          خروج
        </button>
      </div>
    </header>
  );
};