/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';

interface SuggestionBoxProps {
    suggestion: string | null;
    isLoading: boolean;
}

export const SuggestionBox: React.FC<SuggestionBoxProps> = ({ suggestion, isLoading }) => {
    if (isLoading) {
        return (
            <div className="mt-4 p-3 bg-gray-800/50 rounded-lg text-center text-gray-400 animate-pulse">
                جاري التفكير في اقتراح...
            </div>
        );
    }
    
    if (!suggestion) {
        return null;
    }

    return (
        <div className="mt-4 p-3 bg-cyan-900/50 border border-cyan-700 rounded-lg text-center text-cyan-300">
            <span className="font-bold">✨ اقتراح:</span> {suggestion}
        </div>
    );
};