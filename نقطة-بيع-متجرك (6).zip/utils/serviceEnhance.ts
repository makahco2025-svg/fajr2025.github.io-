/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import type { Product } from '../types';

export const mockProducts: Product[] = [
  { id: '8851939302144', name: 'نودلز سريعة التحضير', price: 1.50, imageUrl: 'https://storage.googleapis.com/aistudio-apps/demos/pos/noodles.png', isTaxable: true, stock: 100 },
  { id: '8801062378413', name: 'رقائق بطاطس حارة', price: 2.75, imageUrl: 'https://storage.googleapis.com/aistudio-apps/demos/pos/chips.png', isTaxable: true, stock: 50 },
  { id: '030000030138', name: 'علبة صودا', price: 1.25, imageUrl: 'https://storage.googleapis.com/aistudio-apps/demos/pos/soda.png', isTaxable: true, stock: 120 },
  { id: '4902430689916', name: 'لوح شوكولاتة', price: 2.00, imageUrl: 'https://storage.googleapis.com/aistudio-apps/demos/pos/chocolate.png', isTaxable: false, stock: 80 },
  { id: '073360430032', name: 'مشروب طاقة', price: 3.50, imageUrl: 'https://storage.googleapis.com/aistudio-apps/demos/pos/energy.png', isTaxable: true, stock: 40 },
  { id: '049000050412', name: 'كوكيز', price: 3.20, imageUrl: 'https://storage.googleapis.com/aistudio-apps/demos/pos/cookies.png', isTaxable: false, stock: 60 },
  { id: '8992761132029', name: 'قهوة مثلجة', price: 4.50, imageUrl: 'https://storage.googleapis.com/aistudio-apps/demos/pos/coffee.png', isTaxable: true, stock: 30 },
  { id: '028400048895', name: 'فشار', price: 2.80, imageUrl: 'https://storage.googleapis.com/aistudio-apps/demos/pos/popcorn.png', isTaxable: false, stock: 75 },
  { id: '078000082725', name: 'حبوب إفطار', price: 5.10, imageUrl: 'https://storage.googleapis.com/aistudio-apps/demos/pos/cereal.png', isTaxable: false, stock: 25 },
];