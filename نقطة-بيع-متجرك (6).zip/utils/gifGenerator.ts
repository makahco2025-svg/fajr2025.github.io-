/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// FIX: This file's content was moved to App.tsx.
// The ReportsModal component, which contains JSX, was causing parsing errors
// in this .ts file. React components with JSX should be in .tsx files. To fix
// this without renaming the file, the component was moved to App.tsx.
