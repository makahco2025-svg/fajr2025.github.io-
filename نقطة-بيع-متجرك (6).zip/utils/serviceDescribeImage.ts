/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { GoogleGenAI } from "@google/genai";
import type { CartItem } from '../types';

export const getProductSuggestion = async (cartItems: CartItem[]): Promise<string> => {
    if (cartItems.length === 0) {
        return "";
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const itemNames = cartItems.map(item => item.name).join('، ');

    const prompt = `أنت مساعد بقالة متعاون. لدى العميل العناصر التالية في سلته: ${itemNames}. بناءً على هذه العناصر، اقترح منتجًا إضافيًا واحدًا قد يستمتع به. كن ودودًا واجعل الاقتراح في جملة واحدة. على سبيل المثال، إذا كان لديهم رقائق البطاطس والصودا، يمكنك اقتراح الفشار لأمسية مشاهدة فيلم. لا تستخدم markdown أو أي تنسيق خاص.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
              // Disable thinking for low-latency suggestions
              thinkingConfig: { thinkingBudget: 0 }
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error getting product suggestion:", error);
        return "تعذر جلب اقتراح في الوقت الحالي.";
    }
};